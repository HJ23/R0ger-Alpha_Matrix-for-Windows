


#include "process.h"
#include <iostream>

int main() {
	//create mouse driver create screenrecorder start recording and get image_file process it give result to mouse 
	//                                          ^
	//                                          |________________________________________________________________#

	data_processor a;
	a.init();
	
	
}