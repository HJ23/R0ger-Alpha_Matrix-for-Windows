#pragma once

#include <Windows.h>
struct point_packet {
	POINT point1;
	POINT point2;
};
